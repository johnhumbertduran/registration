<style>
    #confirmPassword{
        border-color: none;
    }
</style>