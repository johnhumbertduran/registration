<style>
    #emailAddress{
        border-color: red;
    }
</style>