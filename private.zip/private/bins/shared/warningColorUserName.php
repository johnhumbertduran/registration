<style>
    #username{
        border-color: red;
    }
</style>