

<style>
    #firstname{
        border-color: none;
    }
</style>