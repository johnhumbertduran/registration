<style>
    #middlename{
        border-color: none;
    }
</style>