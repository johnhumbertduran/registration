<style>
    #regPassword{
        border-color: red;
    }
</style>