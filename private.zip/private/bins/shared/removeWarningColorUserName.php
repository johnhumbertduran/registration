<style>
    #username{
        border-color: none;
    }
</style>