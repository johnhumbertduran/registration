<style>
    #regPassword{
        border-color: none;
    }
</style>