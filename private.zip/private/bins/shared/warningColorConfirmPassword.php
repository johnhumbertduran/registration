<style>
    #confirmPassword{
        border-color: red;
    }
</style>