<style>
    #emailAddress{
        border-color: none;
    }
</style>