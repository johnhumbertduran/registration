<style>
    #firstname{
        border-color: red;
    }
</style>