<?php

//  class User{

//     public $lastName = "";
//     public $first_name = "";
//     public $middleName = "";
//     public $homeAddress = "";
//     public $gender = "";
//     public $civilStatus = "";
//     public $employmentAddress = "";
//     public $currentWork = "";
//     public $currentPosition = "";
//     public $elementary = "";
//     public $elementaryYearGraduated = "";
//     public $highSchool = "";
//     public $highSchoolYearGraduated = "";
//     public $college = "";
//     public $collegeYearGraduated = "";
//     public $collegeDegree = "";
//     public $graduate = "";
//     public $graduateYearGraduated = "";
//     public $graduateDegree = "";
//     public $officeTelephoneNo = "";
//     public $cellphoneNo = "";
//     public $alumniChapterMembership = "";
//     public $email = "";
//     public $username = "";
//     public $password = "";

//  } 

?>